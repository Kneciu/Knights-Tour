package knightstour;

import java.util.ArrayList;
import java.util.List;

public class Map {

    // <editor-fold desc="Fields">
    private int x = 8;
    private int y = 8;
    private Field[][] map;
    // </editor-fold>

    // <editor-fold desc="Constructors">
    public Map() {
        this.x = 8;
        this.y = 8;
        this.map = new Field[this.x][this.y];
        for (int i = 0; i < this.x; i++) {
            for (int j = 0; j < this.y; j++) {
                Field tmp = new Field(8, 8);
                tmp.setPos(i, j);
                this.map[i][j] = tmp;
            }
        }
    }

    public Map(int x, int y) {
        this.x = x;
        this.y = y;
        this.map = new Field[this.x][this.y];
        for (int i = 0; i < this.x; i++) {
            for (int j = 0; j < this.y; j++) {
                Field tmp = new Field(x, y);
                tmp.setPos(i, j);
                this.map[i][j] = tmp;
            }
        }
    }
    // </editor-fold>

    // <editor-fold desc="Methods">
    public Field getField(Position pos) {
        return map[pos.getX()][pos.getY()];
    }

    public Field getField(int x, int y) {
        return map[x][y];
    }

    public void setField(Position pos, Field field) {
        map[pos.getX()][pos.getY()] = field;
    }

    public void setField(int x, int y, Field field) {
        map[x][y] = field;
    }

    public boolean isValid(int fromX, int fromY, int toX, int toY) {
        int x = Math.abs(toX - fromX);
        int y = Math.abs(toY - fromY);

        if (toX < 0) {
            return false;
        }

        if (toY < 0) {
            return false;
        }

        if (toX >= this.getWidth()) {
            return false;
        }

        if (toY >= this.getHeight()) {
            return false;
        }

        if (map[toX][toY].getVisited() == true) {
            return false;
        }

        if (toX < 0 || toY < 0) {
            return false;
        }

        if (x != 1) {
            if (x != 2) {
                return false;
            }
        }

        if (y != 1) {
            if (y != 2) {
                return false;
            }
        }

        if (x == 1 && y != 2) {
            return false;
        }

        if (x == 2 && y != 1) {
            return false;
        }

        return true;
    }

    public List<Position> validMoves(int x, int y) {
        List<Position> posList = new ArrayList<>();

        if (isValid(x, y, x - 2, y - 1)) {
            Position pos = new Position(x - 2, y - 1);
            posList.add(pos);
        }
        if (isValid(x, y, x - 1, y - 2)) {
            Position pos = new Position(x - 1, y - 2);
            posList.add(pos);
        }
        if (isValid(x, y, x + 1, y - 2)) {
            Position pos = new Position(x + 1, y - 2);
            posList.add(pos);
        }
        if (isValid(x, y, x + 2, y - 1)) {
            Position pos = new Position(x + 2, y - 1);
            posList.add(pos);
        }
        if (isValid(x, y, x + 2, y + 1)) {
            Position pos = new Position(x + 2, y + 1);
            posList.add(pos);
        }
        if (isValid(x, y, x + 1, y + 2)) {
            Position pos = new Position(x + 1, y + 2);
            posList.add(pos);
        }
        if (isValid(x, y, x - 1, y + 2)) {
            Position pos = new Position(x - 1, y + 2);
            posList.add(pos);
        }
        if (isValid(x, y, x - 2, y + 1)) {
            Position pos = new Position(x - 2, y + 1);
            posList.add(pos);
        }

        return posList;
    }

    public int getWidth() {
        return this.x;
    }

    public void setWidth(int x) {
        this.x = x;
    }

    public int getHeight() {
        return this.y;
    }

    public void setHeight(int y) {
        this.y = y;
    }

    // </editor-fold>
}
