package knightstour;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.*;
import javax.swing.border.*;

public class Frame extends JFrame implements MouseListener {

    Position pos;
    JPanel chessBoard = new JPanel();
    JLayeredPane layeredPane = new JLayeredPane();
    public Game game;
    Map map;
    Border blackline = BorderFactory.createLineBorder(Color.black);
    static JTextField textfield;
    static boolean solve;

    public Frame(Choice ch) {

        JFrame f = new JFrame("Choice");
        JButton b1 = new JButton("Play");
        JButton b2 = new JButton("Simulation");
        b1.setBounds(80, 90, 140, 40);
        b2.setBounds(80, 140, 140, 40);
        JLabel label = new JLabel();
        label.setText("Choose one");
        label.setBounds(120, 10, 100, 100);

        f.add(label);

        f.add(b1);
        f.add(b2);
        f.setSize(300, 300);
        f.setLayout(null);
        f.setVisible(true);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //b1.addActionListener((event) -> game.setMode(true));
        //b1.addActionListener((event) -> System.exit(0));
        b1.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                game = new Game(5, 5);
                Frame frame = new Frame(game);
                frame.redraw();
            }
        });

        b2.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent arg0) {
                Game game = new Game(5, 5);
                Frame frame = new Frame(game);
                boolean tak = true;
                while (tak) {
                    try {
                        tak = game.bot();
                        frame.redraw();
                        //Thread.sleep(1000);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        });
    }

    public Frame(Game game) {
        this.game = game;
        pos = game.getKnight().getPos();
        Dimension boardSize = new Dimension(800, 800);
        getContentPane().add(layeredPane);
        layeredPane.setPreferredSize(boardSize);
        layeredPane.add(chessBoard, JLayeredPane.DEFAULT_LAYER);
        chessBoard.setLayout(new GridLayout(game.getMap().getWidth(), game.getMap().getHeight()));
        chessBoard.setPreferredSize(boardSize);
        chessBoard.setBounds(0, 0, boardSize.width, boardSize.height);
        createMenuBar();

        initializeChessBoard();

        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        pack();
        setResizable(false);
        setLocationRelativeTo(null);
        setTitle("Knightstour         " + game.title());
        setVisible(true);
        repaint();
    }

    private void initializeChessBoard() {
        for (int i = 0; i < game.getMap().getWidth(); i++) {
            for (int j = 0; j < game.getMap().getHeight(); j++) {

                JPanel square = new JPanel(new BorderLayout());
                chessBoard.add(square);
                square.addMouseListener(this);
                if (game.getKnight().getPos().getX() == i && game.getKnight().getPos().getY() == j) {
                    square.setBackground(Color.red);
                    square.setBorder(blackline);
                } else if (game.getMap().getField(i, j).getVisited() == true) {
                    square.setBackground(Color.orange);
                    square.setBorder(blackline);
                } else if ((i + j) % 2 == 0) {
                    square.setBackground(Color.black);
                    square.setBorder(blackline);
                } else {
                    square.setBackground(Color.white);
                    square.setBorder(blackline);
                }
            }
        }
    }

    @SuppressWarnings("empty-statement")
    private void solveIt() throws InterruptedException {
        if (!Solution.solveGame(game)) {
            setTitle("Knightstour         " + "Not found solution for this game :(");
            revalidate();
            repaint();
            Thread.sleep(5000);
            setTitle("Knightstour         " + game.title());
            revalidate();
            repaint();
            return;
        }

        chessBoard.removeAll();
        int i = 0;
        int j = 0;
        int size = game.map.getHeight() * game.map.getWidth();
        int sizeConst = size;

        while (size > 0) {
            boolean found = false;
            int num = 0;
            JPanel square = new JPanel(new BorderLayout());
            JLabel lab = new JLabel();
            square.setLayout(new GridBagLayout());

            for (Position p : Solution.solutionSequence) {
                if (p.getX() == i && p.getY() == j) {
                    if (num == 0) {
                        square.add(lab = new JLabel("START"), new GridBagConstraints());
                        lab.setFont(new Font("Verdana", 1, 1000 / sizeConst));
                        square.setBackground(Color.red);
                    } else if (num == sizeConst - 1) {
                        square.add(lab = new JLabel("END"), new GridBagConstraints());
                        lab.setFont(new Font("Verdana", 1, 1000 / sizeConst));
                        square.setBackground(Color.cyan);
                    } else {
                        square.add(lab = new JLabel(num + "."), new GridBagConstraints());
                        lab.setFont(new Font("Verdana", 1, 1000 / sizeConst));
                        square.setBackground(Color.lightGray);
                    }

                    found = true;
                }
                num++;
            }
            if (found == true) {
                if (j < game.map.getHeight() - 1) {
                    j++;
                } else {
                    j = 0;
                    ++i;
                }
            } else {
                square.add(lab = new JLabel("Your turn"));
                square.setBackground(Color.orange);
                if (j < game.map.getHeight() - 1) {
                    j++;
                } else {
                    j = 0;
                    ++i;
                }
            }
            System.out.println(i + " " + j);
            square.setBorder(blackline);
            chessBoard.add(square);
            size--;
        }

        Solution.solutionSequence.clear();
        chessBoard.repaint();
        revalidate();
        repaint();
    }

    private void createMenuBar() {

        JMenuBar menubar = new JMenuBar();

        JMenu fileMenu = new JMenu("Menu");
        JMenu helpMenu = new JMenu("Authors");

        JMenuItem eMenuItemSolve = new JMenuItem("Solve it");
        JMenuItem eMenuItemRefresh = new JMenuItem("Refresh");
        JMenuItem eMenuItemExit = new JMenuItem("Exit");
        eMenuItemSolve.addActionListener((event) -> {
            try {
                solveIt();
            } catch (InterruptedException ex) {
                Logger.getLogger(Frame.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        eMenuItemRefresh.addActionListener((ActionEvent event) -> {
            Frame.this.game = new Game(5, 5);
            Frame.this.pos = game.getKnight().getPos();
            redraw();
        });
        eMenuItemExit.addActionListener((event) -> System.exit(0));

        JMenuItem author1 = new JMenuItem("Mateusz Paruzel");

        fileMenu.add(eMenuItemSolve);
        fileMenu.add(eMenuItemRefresh);
        fileMenu.addSeparator();
        fileMenu.add(eMenuItemExit);
        helpMenu.add(author1);
        menubar.add(fileMenu);
        menubar.add(Box.createHorizontalGlue());
        menubar.add(helpMenu);

        setJMenuBar(menubar);
    }

    public void redraw() {
        chessBoard.removeAll();
        for (int i = 0; i < game.getMap().getWidth(); i++) {
            for (int j = 0; j < game.getMap().getHeight(); j++) {

                JPanel square = new JPanel(new BorderLayout());
                chessBoard.add(square);
                square.addMouseListener(this);

                if (game.getKnight().getPos().getX() == i && game.getKnight().getPos().getY() == j) {
                    square.setBackground(Color.red);
                    square.setBorder(blackline);
                } else if (game.getMap().getField(i, j).getVisited() == true) {
                    square.setBackground(Color.orange);
                    square.setBorder(blackline);
                } else if ((i + j) % 2 == 0) {
                    square.setBackground(Color.black);
                    square.setBorder(blackline);
                } else {
                    square.setBackground(Color.white);
                    square.setBorder(blackline);
                }
            }
        }
        setTitle("Knightstour         " + game.title());
        revalidate();
        repaint();
    }

    public void redrawComponent(int id, Position old) {
        chessBoard.getComponent(id).setBackground(Color.red);
        chessBoard.getComponent(old.getX() * game.map.getHeight()
                + old.getY()).setBackground(Color.orange);
        setTitle("Knightstour         " + game.title());
        revalidate();
        repaint();
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        StringTokenizer str = new StringTokenizer(e.getComponent().toString(), ",");
        str.nextToken();
        int y = Integer.parseInt(str.nextToken()) / (800 / game.getMap().getHeight());
        int x = Integer.parseInt(str.nextToken()) / (800 / game.getMap().getWidth());

        if (game.map.isValid(pos.getX(), pos.getY(), x, y)) {
            game.move(x, y);
            redrawComponent(x * game.map.getHeight() + y, pos);
            pos = new Position(x, y);
        }
    }

    // <editor-fold desc="mouse">
    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
    // </editor-fold>

}
