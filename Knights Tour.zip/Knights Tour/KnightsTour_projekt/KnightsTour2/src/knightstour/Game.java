package knightstour;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;

public class Game {

    public Map map;
    private Knight knight;
    private int points;
    private boolean mode = true;

    public Game() {
        this.map = new Map();
        this.knight = new Knight(randomPos(5, 5));
    }

    public Game(int x, int y) {
        this.map = new Map(x, y);
        this.knight = new Knight(randomPos(x, y));
    }

    public Map getMap() {
        return this.map;
    }

    public void setMap(Map map) {
        this.map = map;
    }

    public Knight getKnight() {
        return this.knight;
    }

    public boolean getMode() {
        return this.mode;
    }

    public void setKnight(Knight knight) {
        this.knight = knight;
    }

    public void setMode(boolean mode) {
        this.mode = mode;
    }

    public void switchMode() {
        this.mode = !this.mode;
        System.out.println(this.mode);
    }

    public void move(int x, int y) {
        int fx = knight.getPos().getX();
        int fy = knight.getPos().getY();

        if (map.isValid(fx, fy, x, y)) {
            Position pos = new Position(x, y);
            map.getField(fx, fy).setVisited(true);
            this.knight.setPos(pos);
            points++;
        }
    }

    public void move(Position position) {
        int fx = this.getKnight().getPos().getX();
        int fy = this.getKnight().getPos().getY();

        if (map.isValid(fx, fy, position.getX(), position.getY())) {
            Position pos = new Position(position.getX(), position.getY());
            map.getField(fx, fy).setVisited(true);
            this.knight.setPos(pos);
            points++;
        }
    }

    public int getPoints() {
        return points;
    }

    public String title() {
        return "Masz: " + getPoints() + "pkt";
    }

    public boolean bot() throws InterruptedException {
        List<Position> posList = new ArrayList<>();
        posList = this.map.validMoves(this.getKnight().getPos().getX(), this.getKnight().getPos().getY());
        System.out.println("size: " + posList.size());
        if (posList.size() == 0) {
            return false;
        } else {
            int random = (int) (Math.random() * posList.size());
            System.out.println("random: " + random);
            System.out.println("X: " + posList.get(random).getX() + " Y: " + posList.get(random).getY());
            this.move(posList.get(random));
            posList.clear();
            return true;
        }
    }

    private static List<Position> loadFromFile(int x, int y) {
        List<Position> posList = new ArrayList<>();
        File file = new File("start.txt");
        String line = "";
        FileInputStream fin = null;
        BufferedReader inbr = null;
        try {
            fin = new FileInputStream(file);
            inbr = new BufferedReader(new InputStreamReader(fin));
            while ((line = inbr.readLine()) != null) {
                StringTokenizer str = new StringTokenizer(line, " ");
                int xx = Integer.parseInt(str.nextToken());
                int yy = Integer.parseInt(str.nextToken());
                if ((yy == y) && (xx == x)) {
                    int tokens = str.countTokens() / 2;
                    while ((tokens--) != 0) {
                        posList.add(new Position(Integer.parseInt(str.nextToken()), Integer.parseInt(str.nextToken())));
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Read/write error");
        } finally {
            if (inbr != null) {
                try {
                    inbr.close();
                } catch (IOException ex) {
                }
            }
        }
        return posList;
    }

    private static Position randomPos(int x, int y) {
        List<Position> posList = new ArrayList<>();
        posList = loadFromFile(x, y);
        Random rand = new Random();
        Position pos = posList.get(rand.nextInt(posList.size()));
        return new Position(pos.getX(), pos.getY());
    }
}
