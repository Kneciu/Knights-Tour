package knightstour;

public class Position {

    // <editor-fold desc="Fields">
    private int x = 0;
    private int y = 0;
    // </editor-fold>

    // <editor-fold desc="Constructors">
//    public Position() {
//        this(2, 2);
//    }

    public Position(int x, int y) {
        this.x = x;
        this.y = y;
    }
    // </editor-fold>

    // <editor-fold desc="Methods">
    public int getX() {
        return this.x;
    }

    public int getY() {
        return this.y;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }
    // </editor-fold>
}
