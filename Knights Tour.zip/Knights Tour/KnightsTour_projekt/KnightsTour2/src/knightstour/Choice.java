/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package knightstour;

public class Choice {
    private int ch = 0;
    
    public void setCh(int ch)
    {
        this.ch = ch;
    }
    
    public int getCh()
    {
        return this.ch;
    }
}
