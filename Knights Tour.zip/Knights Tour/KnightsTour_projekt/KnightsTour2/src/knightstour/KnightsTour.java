package knightstour;

import java.awt.EventQueue;
import javax.swing.*;

public class KnightsTour extends JFrame {
    
   
    public static void main(String[] args) throws InterruptedException {  
        
        
        
        Choice ch = new Choice();
        
        Frame frame1 = new Frame(ch); 
        
//        if(ch.getCh() == 1)
//        {
//            Game game = new Game(8, 8);
//            EventQueue.invokeLater(() -> {
//                Frame frame = new Frame(game);
//                frame.redraw();                
//            });
//        }
//        else if(ch.getCh() == 2)
//        {
//            Game game = new Game(8, 8);
//            Frame frame = new Frame(game);
//            boolean  tak = true;
//            while(tak)
//            {
//                tak = game.bot();
//                frame.redraw();
//                Thread.sleep(1000);
//            }
//        } 
    }   
    
}
