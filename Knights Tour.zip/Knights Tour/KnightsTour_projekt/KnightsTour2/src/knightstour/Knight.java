package knightstour;

public class Knight {

    // <editor-fold desc="Fields">
    private String name;
    private Position pos;
    // </editor-fold>
    
    // <editor-fold desc="Constructors">
//    public Knight() {
//        this.name = "name";
//        this.pos = new Position();
//    }
//    
//    public Knight(String name) {
//        this.name = name;
//        this.pos = new Position();
//    }
    
    public Knight(Position pos) {
        this.name = "name";
        this.pos = pos;
    }
    
    public Knight(int x, int y) {
        this.name = "name";
        this.pos = new Position(x, y);
    }
    
    public Knight(String name, Position pos) {
        this.name = name;
        this.pos = pos;
    }
    
    public Knight(String name, int x, int y) {
        this.name = name;
        this.pos = new Position(x, y);
    }
    // </editor-fold>

    // <editor-fold desc="Methods">
    public String getName() {
        return this.name;
    }
    
    public Position getPos() {
        return this.pos;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public void setPos(Position pos) {
        this.pos = pos;
    }
    
    public void setPos(int x, int y) {
        this.pos = new Position(x, y);
    }
    // </editor-fold>
}
