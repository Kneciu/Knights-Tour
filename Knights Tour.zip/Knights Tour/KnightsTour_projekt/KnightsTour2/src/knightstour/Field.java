package knightstour;

public class Field {
    
    // <editor-fold desc="Fields">
    private boolean visited;
    private boolean universal;
    private Position pos;
    // </editor-fold>
    
    // <editor-fold desc="Constructors">
//    public Field() {
//        this.visited = false;
//        this.universal = false;
//        this.pos = new Position();
//    }
    
//    public Field(boolean universal) {
//        this.visited = false;
//        this.universal = universal;
//        this.pos = new Position();
//    }
    
    public Field(Position pos) {
        this.visited = false;
        this.universal = false;
        this.pos = pos;
    }
    
    public Field(int x, int y) {
        this.visited = false;
        this.universal = false;
        this.pos = new Position(x, y);
    }
    
    public Field(boolean universal, Position pos) {
        this.visited = false;
        this.universal = universal;
        this.pos = pos;
    }
    
    public Field(boolean universal, int x, int y) {
        this.visited=  false;
        this.universal = universal;
        this.pos = new Position(x, y);
    }
    // </editor-fold>
    
    // <editor-fold desc="Methods">
    public boolean getVisited() {
        return this.visited;
    }
    
    public boolean getUniversal() {
        return this.universal;
    }
    
    public Position getPos() {
        return this.pos;
    }
    
    public void setVisited(boolean visited) {
        this.visited = visited;
    }
    
    public void setUniversal(boolean universal) {
        this.universal = universal;
    }
    
    public void setPos(Position pos) {
        this.pos = pos;
    }
    
    public void setPos(int x, int y) {
        this.pos = new Position(x, y);
    }
    // </editor-fold>
}
