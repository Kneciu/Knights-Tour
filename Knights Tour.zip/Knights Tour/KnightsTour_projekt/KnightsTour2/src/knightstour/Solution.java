/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package knightstour;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Deque;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.StringTokenizer;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class Solution {

    static int total;
    static boolean searchFirstFlag = false;
    static Deque<Position> solutionSequence = new LinkedList<>();

    public static boolean solveGame(Game game) {

        Game gm = game;

        int x = gm.getMap().getHeight();
        int y = gm.getMap().getWidth();
        int points = gm.getPoints();
        Position pos = gm.getKnight().getPos();
        total = (x * y);
        searchFirstFlag = false;
        Map map = gm.getMap();

        solve(map, pos, points);
        System.out.println("Pts" + points);
        if (solutionSequence.size() < total - points - 1) {
            System.out.println(total - points);
            solutionSequence.clear();
            return false;
        }
        
        solutionSequence.forEach((p) -> {
            gm.move(p);
        });
        
        solutionSequence.add(gm.map.validMoves(
                solutionSequence.getLast().getX(),
                solutionSequence.getLast().getY()
            ).get(0));
        
        return true;
    }

    public static void solve(Map map, Position pos, int count) {

        if (searchFirstFlag) {
            return;
        }

        map.getField(pos).setVisited(true);

        if (count >= total - 1) {
            map.getField(pos).setVisited(false);
            searchFirstFlag = true;
            return;
        }

        List<Position> availablePos = new ArrayList<>();
        availablePos = map.validMoves(pos.getX(), pos.getY());

        for (Position p : availablePos) {
            solve(map, p, count + 1);
        }

        map.getField(pos).setVisited(false);
        if (searchFirstFlag) {
            solutionSequence.addFirst(pos);
        }
    }

    public static void saveToFile(int n) {

        try (FileWriter fileWriter = new FileWriter("start.txt", true);) {

            searchFirstFlag = false;
            total = n * n;
            fileWriter.append(n + " " + n + " ");
            int tmp = n - 1;
            boolean nIsParzyste = ((n % 2) == 0);
            if (nIsParzyste) {
                for (int i = 0; i < n / 2; i++) {
                    for (int j = 0; j < n / 2; j++) {
                        solve(new Map(n, n), new Position(i, j), 0);
                        if (searchFirstFlag == true) {
                            fileWriter.append(i + " " + j + " "
                                    + (tmp - i) + " " + j + " "
                                    + i + " " + (tmp - j) + " "
                                    + (tmp - i) + " " + (tmp - j) + " ");
                            System.out.println(i + " " + j);
                            searchFirstFlag = false;
                        }
                    }
                }
            } else {
                for (int i = 0; i <= n / 2; i++) {
                    for (int j = 0; j < n / 2; j++) {
                        solve(new Map(n, n), new Position(i, j), 0);
                        if (searchFirstFlag == true) {
                            if (i == (n / 2)) {
                                fileWriter.append(i + " " + j + " "
                                        + j + " " + i + " "
                                        + i + " " + (tmp - j) + " "
                                        + (tmp - j) + " " + i + " ");
                            } else {
                                fileWriter.append(i + " " + j + " "
                                        + (tmp - i) + " " + j + " "
                                        + i + " " + (tmp - j) + " "
                                        + (tmp - i) + " " + (tmp - j) + " ");
                            }
                            searchFirstFlag = false;
                        }
                    }
                }
                solve(new Map(n, n), new Position(n / 2, n / 2), 0);
                if (searchFirstFlag == true) {
                    fileWriter.append(n / 2 + " " + n / 2 + " ");
                    searchFirstFlag = false;
                }
            }

            fileWriter.append(System.getProperty("line.separator"));
            fileWriter.close();
        } catch (IOException ex) {
            System.out.println("Solution: saveToFile: " + ex);
        }
    }

    private static List<Position> loadFromFile(int x, int y) {
        List<Position> posList = new ArrayList<>();
        File file = new File("start.txt");
        String line;
        FileInputStream fin = null;
        BufferedReader inbr = null;
        try {
            fin = new FileInputStream(file);
            inbr = new BufferedReader(new InputStreamReader(fin));
            while ((line = inbr.readLine()) != null) {
                StringTokenizer str = new StringTokenizer(line, " ");
                int xx = Integer.parseInt(str.nextToken());
                int yy = Integer.parseInt(str.nextToken());
                if ((yy == y) && (xx == x)) {
                    int tokens = str.countTokens() / 2;
                    while ((tokens--) != 0) {
                        posList.add(new Position(Integer.parseInt(str.nextToken()), Integer.parseInt(str.nextToken())));
                    }
                }
            }
        } catch (IOException e) {
            System.out.println("Read/write error");
        } finally {
            if (inbr != null) {
                try {
                    inbr.close();
                } catch (IOException ex) {
                }
            }
        }
        return posList;
    }

    public static Position randomPosition(int x, int y) {
        List<Position> posList = new ArrayList<>();
        posList = loadFromFile(x, y);
        Random rand = new Random();
        Position pos = posList.get(rand.nextInt(posList.size()));
        return new Position(pos.getX(), pos.getY());
    }
    
    public static void main(String[] args) {
        saveToFile(7);
    }
}
